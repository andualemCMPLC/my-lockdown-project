import './test.js';

mocha.checkLeaks();
mocha.run();
